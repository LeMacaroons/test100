# TA_oracle_sbc_radius

Splunk Cloud search-time field extraction for Oracle SBC RADIUS Stop CDRs normalized by FreeRADIUS.

- Sourcetype: `oracle:sbc:radius`
- Format: pipe-delimited
- Schema: 98 fields
- Extraction: search-time via `REPORT-oracle-sbc-radius`
- Empty optional attributes are retained with `KEEP_EMPTY_VALS = true`

The Universal Forwarder `inputs.conf` is intentionally not included in this Cloud app.
